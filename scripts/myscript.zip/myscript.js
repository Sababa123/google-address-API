 var date = new Date();
    var currentMonth = date.getMonth();
                    var currentDate = date.getDate();
                    var currentYear = date.getFullYear();
                    var today=new Date(currentYear, currentMonth, currentDate);
                        var week = new Date(currentYear, currentMonth, currentDate + 6);
                        var fdays = new Date(currentYear, currentMonth, currentDate + 14);
                        var tedays = new Date(currentYear, currentMonth, currentDate + 27);                        
                        $("#r1:radio").click(function () {
                            rdrp(today, week);
                            $("#from").attr("disabled", "disabled"); 
                            $("#to").attr("disabled", "disabled"); 
                            
                        });
                        $("#r2:radio").click(function () {
                            rdrp(today, fdays);
                            $("#from").attr("disabled", "disabled"); 
                            $("#to").attr("disabled", "disabled"); 
                        });
                        $("#r3:radio").click(function () {
                            rdrp(today, tedays);
                            $("#from").attr("disabled", "disabled"); 
                            $("#to").attr("disabled", "disabled"); 
                        });
                        $("#r4:radio").click(function () {
                            rdrp(today, week);
                            $("#from").removeAttr("disabled");
                            $("#to").removeAttr("disabled"); 
                            
                        });
          function rdrp (from,to) {
                    $('input[name="from"]').daterangepicker({
                        minDate: new Date(currentYear, currentMonth, currentDate),
                        autoApply: true
                        , dateFormat: 'yy-mm-dd'
                        , startDate: moment(from).add('days')
                        , endDate: moment(to).add('days')
                        , locale: {
                            format: 'dd, DD/MM'
                        }
                    });
}
                function init() {
                    var options = {
                        types: ['(cities)']
                    };

                    var input = document.getElementById('locationName');
                    var input1 = document.getElementById('locationName2');
                    
                    var autocomplete = new google.maps.places.Autocomplete(input, options);
                    var autocomplete1 = new google.maps.places.Autocomplete(input1, options);
                    
                }
                google.maps.event.addDomListener(window, 'load', init);


              